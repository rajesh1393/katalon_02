import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;

fileInputStream = new FileInputStream(GlobalVariable.File_TestData);

			HSSFWorkbook workbook = new HSSFWorkbook(fileInputStream);
String sheet;
			// for each sheet in the workbook
			for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
				GlobalVariable.Sheetname=workbook.getSheetName(i)
				System.out.println("Sheet name: " + GlobalVariable.Sheetname);
			String input=GlobalVariable.File_Addsheet_name;
				if(GlobalVariable.Sheetname.equals(input))
					{
						println "workbook.getSheetName(i)${GlobalVariable.Sheetname}"
						sheet= GlobalVariable.Sheetname;
						println "sheet:{$sheet}"
						}
				}
			println "GlobalVariable.Sheetname:${GlobalVariable.Sheetname}"
			CustomKeywords.'utils.ExcelUtils.setExcelFile'(GlobalVariable.File_TestData,GlobalVariable.Sheetname);
			int rowNum=CustomKeywords.'utils.ExcelUtils.getRowCount'(sheet);
			System.out.println(rowNum);
			for(int i=1;i<rowNum;i++)
			{
			String ContactCategory=CustomKeywords.'utils.ExcelUtils.getCellData'(i, 0);
			String CompanyName=CustomKeywords.'utils.ExcelUtils.getCellData'(i, 1);
			println "contactcategory:${ContactCategory}"
			println "CompanyName:${CompanyName}"
			}
			
		