import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import java.io.FileInputStream;
import java.io.FileOutputStream;
import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFCellStyle;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.hssf.util.HSSFColor;
import org.openqa.selenium.WebDriver

static WebDriver driver
String action = "";
String value = "";
String attribute = "";
String attrval = "";
 
try {
	// Open the Excel file for reading
	FileInputStream fis = new FileInputStream("C:\\Users\\rajesh\\Desktop\\TestData.xls");
	// Open it for writing too
	// Access the required test data sheet
	HSSFWorkbook wb = new HSSFWorkbook(fis);
	HSSFSheet sheet = wb.getSheet("steps");
	// Loop through all rows in the sheet
	// Start at row 1 as row 0 is our header row
	int number=sheet.getLastRowNum();
	println "number:${number}"
	for(int count = 1;count<number;count++){
		HSSFRow row = sheet.getRow(count);
		System.out.println("Running test step " + row.getCell(0).toString());

		// Run the test step for the current test data row
		if(!(row.getCell(1) == null || row.getCell(1).equals(org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK))) {
			action = row.getCell(1).toString();
		} else {
			action = "";
		}

		if(!(row.getCell(2) == null || row.getCell(2).equals(org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK))) {
			value = row.getCell(2).toString();
			println "value:${value}"
		} else {
			value = "";
		}

		if(!(row.getCell(3) == null || row.getCell(3).equals(org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK))) {
			attribute = row.getCell(3).toString();
		} else {
			attribute = "";
		}

		if(!(row.getCell(4) == null || row.getCell(4).equals(org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BLANK))) {
			attrval = row.getCell(4).toString();
		} else {
			attrval = "";
		}

		System.out.println("Test action: " + action);
		System.out.println("Parameter value: " + value);
		System.out.println("Attribute: " + attribute);
		System.out.println("Attribute value: " + attrval);
		 
		String result = CustomKeywords.'pac.runteststeps.steps'(driver,action,value,attribute,attrval);
		/*// Write the result back to the Excel sheet
		row.createCell(5).setCellValue(result);
	// Save the Excel sheet and close the file streams
	FileOutputStream fos = new FileOutputStream("C:\\Users\\rajesh\\Desktop\\TestData.xls");
    wb.write(fos);
	fis.close();
	fos.close();*/
	} 
} catch (Exception e) {
	System.out.println(e.toString());
}
