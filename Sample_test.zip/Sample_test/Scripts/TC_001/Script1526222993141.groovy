import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.testobject.TestObjectProperty
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import internal.GlobalVariable as GlobalVariable
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.thoughtworks.selenium.Selenium as Selenium
import org.openqa.selenium.firefox.FirefoxDriver as FirefoxDriver
import org.openqa.selenium.By as By
import org.openqa.selenium.WebDriver as WebDriver
import com.thoughtworks.selenium.webdriven.WebDriverBackedSelenium as WebDriverBackedSelenium
import static org.junit.Assert.*
import java.util.regex.Pattern as Pattern
import static org.apache.commons.lang3.StringUtils.join

WebUI.openBrowser('')
TestObject to=new TestObject();
to.getProperties().add(findTestObject('Object Repository/Button_1'))
println ("test{$to}")

def driver = DriverFactory.getWebDriver()

/*String baseUrl = "https://www.katalon.com/"
selenium = new WebDriverBackedSelenium(driver, baseUrl)
selenium.open("https://store.volusion.com/login.asp?Return_Token=Y&RedirectTo=http%3a%2f%2fmy.volusion.com%2fdefault.aspx")
selenium.click("name=email")
selenium.type("name=email", "harirajesh22@gmail.com")
selenium.click("name=password")
selenium.type("name=password", "nokix302")
selenium.click("name=imageField2")
*/
String[] invalidChars = ['#', '!', '@', '%', '^', '&']

String name = 'acbcdefghijklmnopqrstuvwxyzab'

//	d = new FirefoxDriver();
//	d.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
driver.get('http://www.vrlbus.in/vrl2013/register_customer.aspx')

driver.manage().window().maximize()
for (String invalid : invalidChars) {
    

    driver.findElement(By.id('FIRSTNAME')).clear()

    driver.findElement(By.id('FIRSTNAME')).sendKeys(name + invalid)

    Thread.sleep(2000)

    WebUI.scrollToElement(findTestObject('Object Repository/Button_1'), 0)
println 'test'
    driver.findElement(By.id('Button1')).click()

	Thread.sleep(3000)
    String alertMessage = driver.switchTo().alert().getText()

    System.out.println(invalid);

    if (alertMessage.equals('First name Should not contain Special Characters')) {
        System.out.println('Error displayed: First name Should not contain Special Characters')

        driver.switchTo().alert().dismiss()
    } else if((alertMessage.equals('Please Enter Your Last Name')) {
        System.out.println('Accepted')
    }
}
driver.findElement(By.id('FIRSTNAME')).sendKeys('acbcdefghijklmnopqrstuvwxyzabcdef')

driver.findElement(By.id('Button1')).click()

String alertMessage = driver.switchTo().alert().getText()

if (alertMessage.equals('First name Should not contain Special Characters')) {
    System.out.println('Error displayed: First name Should not contain Special Characters')

    driver.switchTo().alert().dismiss()
} else {
    System.out.println('Accepted')
}

driver.quit()
